package com.imagezoom.utils;

public interface IDisposable {

	void dispose();
}
